<?php
/**
 * Baskonfiguration för WordPress.
 *
 * Denna fil används av wp-config.php-genereringsskript under installationen.
 * Du behöver inte använda webbplatsens installationsrutin, utan kan kopiera
 * denna fil direkt till "wp-config.php" och fylla i alla värden.
 *
 * Denna fil innehåller följande konfigurationer:
 *
 * * Inställningar för MySQL
 * * Säkerhetsnycklar
 * * Tabellprefix för databas
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL-inställningar - MySQL-uppgifter får du från ditt webbhotell ** //
/** Namnet på databasen du vill använda för WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL-databasens användarnamn */
define( 'DB_USER', 'root' );

/** MySQL-databasens lösenord */
define( 'DB_PASSWORD', '' );

/** MySQL-server */
define( 'DB_HOST', 'localhost' );

/** Teckenkodning för tabellerna i databasen. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Kollationeringstyp för databasen. Ändra inte om du är osäker. */
define('DB_COLLATE', '');

/**#@+
 * Unika autentiseringsnycklar och salter.
 *
 * Ändra dessa till unika fraser!
 * Du kan generera nycklar med {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * Du kan när som helst ändra dessa nycklar för att göra aktiva cookies obrukbara, vilket tvingar alla användare att logga in på nytt.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'sOp6Qy7I(sM{wZsp(sTI:L%U;Wd(vG #tW EF^Pf*VIUH:[T|IUhn<e,#yw&Y&ap' );
define( 'SECURE_AUTH_KEY',  ')!z,4AeI!.CM&y,^odN2BVLJ,Yd5sC%k3:I@Y`4yWrR]7pE8%8!d1BL?cy[RG}o<' );
define( 'LOGGED_IN_KEY',    'tN;.=5D,zq>Q&gU57J``2fU4}L|aK #`@M<Ea#X<=:7<!_0@-S^0Y.eZEez#6VMG' );
define( 'NONCE_KEY',        'QS^xF`h_=MFr3@33HReu,Z;]{oK+7D96ZdQpIGCAozCLcIS)<]HD*Vlx69,h9{bF' );
define( 'AUTH_SALT',        'Kapjhl0`y+fsJ9fH>(/}3s`+!0REKuG.=#eL13BhM75GFUq)x$.@4s9Kxdx>C&8E' );
define( 'SECURE_AUTH_SALT', 'xFRjD$}pajt&t^F7~vFU%tdofq5KZdAF<aea<xm@t[e]Q;M;o_N~.Nc3(t-=V_qA' );
define( 'LOGGED_IN_SALT',   'V}LU-b?(=?g7}:!yo,3-cKFaEHkm`!wd/[A8#Sbf35R@x,HbrHd}/F<vaJXmB}W]' );
define( 'NONCE_SALT',       'WDn3i?,2KC#RCElk5@s/r,u~DU|0i$BFQ?Xxd,NKg)<>#E!+/97aZS`v1t1FVE/8' );

/**#@-*/

/**
 * Tabellprefix för WordPress-databasen.
 *
 * Du kan ha flera installationer i samma databas om du ger varje installation ett unikt
 * prefix. Använd endast siffror, bokstäver och understreck!
 */
$table_prefix = 'wp_';

/** 
 * För utvecklare: WordPress felsökningsläge. 
 * 
 * Ändra detta till true för att aktivera meddelanden under utveckling. 
 * Det rekommenderas att man som tilläggsskapare och temaskapare använder WP_DEBUG 
 * i sin utvecklingsmiljö. 
 *
 * För information om andra konstanter som kan användas för felsökning, 
 * se dokumentationen. 
 * 
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */ 
define('WP_DEBUG', false);

/* Det var allt, sluta redigera här och börja publicera! */

/** Absolut sökväg till WordPress-katalogen. */
if ( !defined('ABSPATH') )
	define('ABSPATH', __DIR__ . '/');

/** Anger WordPress-värden och inkluderade filer. */
require_once(ABSPATH . 'wp-settings.php');